// استيراد المكتبات اللازمة
import React, { useState, useEffect } from 'react';
import './App.css'; // استيراد ملف الأنماط الخاص بالتطبيق

// استيراد المكونات الرئيسية
import Sidebar from './components/Sidebar/Sidebar';
import Header from './components/Header/Header';
import MainContent from './components/MainContent/MainContent';

// تعريف مكون التطبيق الرئيسي
function App() {
  // حالة لتتبع حجم الشاشة للتجاوب
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);
  // حالة لتتبع ما إذا كان السايدبار مفتوحاً أم لا (للشاشات الصغيرة)
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // استخدام useEffect لتتبع تغييرات حجم الشاشة
  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
      // إغلاق السايدبار تلقائياً في الشاشات الصغيرة
      if (window.innerWidth < 992) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };

    // إضافة مستمع الحدث
    window.addEventListener('resize', handleResize);
    
    // تنظيف مستمع الحدث عند إزالة المكون
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // دالة لتبديل حالة السايدبار
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="app-container">
      {/* مكون السايدبار مع إضافة كلاس للتحكم في الظهور */}
      <div className={`sidebar-wrapper ${isSidebarOpen ? 'open' : 'closed'}`}>
        <Sidebar />
      </div>
      
      {/* منطقة المحتوى الرئيسي */}
      <div className={`content-wrapper ${isSidebarOpen ? 'with-sidebar' : 'without-sidebar'}`}>
        {/* مكون الهيدر مع تمرير دالة تبديل السايدبار */}
        <Header toggleSidebar={toggleSidebar} />
        
        {/* مكون المحتوى الرئيسي */}
        <MainContent />
      </div>
    </div>
  );
}

// تصدير المكون لاستخدامه في ملف الدخول الرئيسي
export default App;
