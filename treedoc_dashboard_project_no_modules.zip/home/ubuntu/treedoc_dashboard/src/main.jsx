// استيراد المكتبات الأساسية
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './index.css'; // استيراد الأنماط العامة

// استيراد أنماط Bootstrap الأساسية
import 'bootstrap/dist/css/bootstrap.min.css';

// رندر التطبيق الرئيسي في الـ DOM
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);

