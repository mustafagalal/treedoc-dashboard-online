// استيراد المكتبات اللازمة
import React from 'react';
import './MainContent.css'; // استيراد ملف الأنماط الخاص بالمحتوى الرئيسي
import { Container, Row, Col } from 'react-bootstrap'; // استيراد مكونات التخطيط من بوتستراب

// استيراد المكونات الداخلية للمحتوى الرئيسي
import WelcomeCard from '../WelcomeCard/WelcomeCard';
import TasksCard from '../TasksCard/TasksCard';
import QuickSearch from '../QuickSearch/QuickSearch';
import AdvancedSearch from '../AdvancedSearch/AdvancedSearch';
import RecentSection from '../RecentSection/RecentSection';
import ClassificationSection from '../ClassificationSection/ClassificationSection';

// تعريف مكون المحتوى الرئيسي الوظيفي
const MainContent = () => {
    return (
        <div className="main-content-area p-4">
            <Container fluid>
                {/* صف يحتوي على بطاقة الترحيب وبطاقة المهام */}
                <Row className="mb-4">
                    <Col md={7}> {/* العمود الخاص ببطاقة الترحيب */}
                        <WelcomeCard />
                    </Col>
                    <Col md={5}> {/* العمود الخاص ببطاقة المهام */}
                        <TasksCard />
                    </Col>
                </Row>

                {/* صف يحتوي على أقسام البحث والأحدث والتصنيف */}
                <Row>
                    {/* العمود الأيسر: البحث السريع والمتقدم والأحدث */}
                    <Col md={8}>
                        <QuickSearch />
                        <AdvancedSearch />
                        <RecentSection />
                    </Col>
                    
                    {/* العمود الأيمن: التصنيف */}
                    <Col md={4}>
                        <ClassificationSection />
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

// تصدير المكون لاستخدامه في أماكن أخرى
export default MainContent;

