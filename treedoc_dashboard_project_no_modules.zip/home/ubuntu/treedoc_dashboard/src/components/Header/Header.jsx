// استيراد المكتبات والأيقونات اللازمة
import React from 'react';
import './Header.css'; // استيراد ملف الأنماط الخاص بالهيدر
import { FaLightbulb, FaInfoCircle, FaFont, FaBell, FaUserCircle } from 'react-icons/fa'; // استيراد الأيقونات
import { Button, ButtonGroup } from 'react-bootstrap'; // استيراد مكونات بوتستراب للأزرار

// تعريف مكون الهيدر الوظيفي
const Header = () => {

    // دالة لمعالجة الضغط على أيقونات الهيدر (مثال)
    const handleIconClick = (iconName) => {
        console.log(`${iconName} icon clicked`);
        // يمكنك إضافة منطق محدد لكل أيقونة هنا
        // مثلاً: فتح قائمة الإشعارات عند الضغط على الجرس
    };

    return (
        <div className="header-container d-flex justify-content-end align-items-center p-3">
            {/* مجموعة الأيقونات في الهيدر */}
            <ButtonGroup aria-label="Header Icons">
                {/* زر أيقونة اللمبة */}
                <Button variant="link" className="header-icon-btn" onClick={() => handleIconClick('Lightbulb')}>
                    <FaLightbulb />
                </Button>
                {/* زر أيقونة المعلومات */}
                <Button variant="link" className="header-icon-btn" onClick={() => handleIconClick('Info')}>
                    <FaInfoCircle />
                </Button>
                {/* زر أيقونة حجم الخط */}
                <Button variant="link" className="header-icon-btn" onClick={() => handleIconClick('Font')}>
                    <FaFont /> {/* ملاحظة: الأيقونة في الصورة مختلفة قليلاً، استخدمت FaFont كبديل */}
                </Button>
                {/* زر أيقونة الجرس (الإشعارات) */}
                <Button variant="link" className="header-icon-btn" onClick={() => handleIconClick('Bell')}>
                    <FaBell />
                </Button>
                {/* زر أيقونة المستخدم */}
                <Button variant="link" className="header-icon-btn" onClick={() => handleIconClick('User')}>
                    <FaUserCircle />
                </Button>
            </ButtonGroup>
        </div>
    );
};

// تصدير المكون لاستخدامه في أماكن أخرى
export default Header;

