// استيراد المكتبات اللازمة
import React, { useState, useEffect } from 'react';
import './WelcomeCard.css'; // استيراد ملف الأنماط الخاص ببطاقة الترحيب
import { Card } from 'react-bootstrap'; // استيراد مكون Card من react-bootstrap

// تعريف مكون بطاقة الترحيب الوظيفي
const WelcomeCard = () => {
    // تعريف حالة لتخزين الوقت والتاريخ الحاليين
    const [currentDateTime, setCurrentDateTime] = useState(new Date());
    // تعريف حالة لتخزين اسم المستخدم (يمكن جلبه من API لاحقاً)
    const [userName, setUserName] = useState('Mustafa');

    // استخدام useEffect لتحديث الوقت كل دقيقة
    useEffect(() => {
        // تعيين مؤقت لتحديث الوقت كل دقيقة
        const timer = setInterval(() => {
            setCurrentDateTime(new Date());
        }, 60000); // 60000 مللي ثانية = دقيقة واحدة

        // تنظيف المؤقت عند إزالة المكون
        return () => {
            clearInterval(timer);
        };
    }, []); // المصفوفة الفارغة تعني أن هذا التأثير يحدث مرة واحدة فقط عند التحميل

    // تنسيق الوقت والتاريخ
    const formattedDateTime = currentDateTime.toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: 'numeric', 
        hour12: true 
    }) + ' ' + currentDateTime.toLocaleDateString('en-US', { 
        weekday: 'long', 
        month: 'long', 
        day: 'numeric', 
        year: 'numeric' 
    });

    return (
        <Card className="welcome-card shadow-sm">
            <Card.Body>
                {/* نص الترحيب */}
                <Card.Title as="h5" className="welcome-title">Welcome Back</Card.Title>
                {/* اسم المستخدم */}
                <Card.Text as="h2" className="user-name mb-3">{userName}</Card.Text>
                {/* التاريخ والوقت */}
                <Card.Text className="date-time">
                    {formattedDateTime}
                </Card.Text>
            </Card.Body>
        </Card>
    );
};

// تصدير المكون لاستخدامه في أماكن أخرى
export default WelcomeCard;
