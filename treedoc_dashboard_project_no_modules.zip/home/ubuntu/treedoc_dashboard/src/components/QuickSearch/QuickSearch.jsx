// استيراد المكتبات اللازمة
import React, { useState } from 'react'; // استيراد useState لإدارة الحالة
import './QuickSearch.css'; // استيراد ملف الأنماط الخاص بالبحث السريع
import { Form, InputGroup, Button } from 'react-bootstrap'; // استيراد مكونات بوتستراب
import { FaSearch } from 'react-icons/fa'; // استيراد أيقونة البحث

// تعريف مكون البحث السريع الوظيفي
const QuickSearch = () => {
    // تعريف حالة لتخزين قيمة البحث
    const [searchTerm, setSearchTerm] = useState('');

    // دالة لمعالجة التغيير في حقل الإدخال
    const handleInputChange = (event) => {
        setSearchTerm(event.target.value);
    };

    // دالة لمعالجة الضغط على زر البحث
    const handleSearchClick = () => {
        // هنا يمكنك إضافة منطق البحث الفعلي
        // حالياً، سنقوم فقط بطباعة قيمة البحث في الكونسول
        console.log('Quick Search Term:', searchTerm);
        // يمكنك استدعاء دالة بحث تمرر لها searchTerm
    };

    // دالة لمعالجة الضغط على Enter في حقل الإدخال
    const handleKeyPress = (event) => {
        if (event.key === 'Enter') {
            event.preventDefault(); // منع السلوك الافتراضي للـ Enter في النموذج
            handleSearchClick();
        }
    };

    return (
        <div className="quick-search-container">
            {/* عنوان قسم البحث السريع */}
            <h5 className="search-title">Quick search</h5>
            
            {/* نموذج البحث */}
            <Form onSubmit={(e) => e.preventDefault()}> {/* منع إرسال النموذج الافتراضي */}
                <InputGroup className="mb-3">
                    {/* حقل إدخال البحث */}
                    <Form.Control
                        placeholder="Search"
                        aria-label="Search"
                        className="search-input"
                        value={searchTerm} // ربط القيمة بالحالة
                        onChange={handleInputChange} // ربط دالة معالجة التغيير
                        onKeyPress={handleKeyPress} // ربط دالة معالجة Enter
                    />
                    {/* زر البحث مع أيقونة */}
                    <Button 
                        variant="outline-secondary" 
                        className="search-button"
                        onClick={handleSearchClick} // ربط دالة معالجة الضغط
                    >
                        <FaSearch />
                    </Button>
                </InputGroup>
            </Form>
        </div>
    );
};

// تصدير المكون لاستخدامه في أماكن أخرى
export default QuickSearch;
