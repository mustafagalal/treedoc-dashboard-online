// استيراد المكتبات اللازمة
import React from 'react';
import './ClassificationSection.css'; // استيراد ملف الأنماط الخاص بقسم التصنيف
import { Card } from 'react-bootstrap'; // استيراد مكون Card
import { FaFolderTree } from 'react-icons/fa'; // استيراد أيقونة مناسبة (يمكن تغييرها)

// تعريف مكون قسم التصنيف الوظيفي
const ClassificationSection = () => {
    return (
        <div className="classification-section-container">
            {/* عنوان القسم مع أيقونة */}
            <h5 className="section-title d-flex align-items-center">
                <FaFolderTree className="me-2" /> {/* أيقونة التصنيف */}
                Classification
            </h5>
            
            {/* بطاقة لعرض محتوى التصنيف */}
            <Card className="classification-card">
                <Card.Body className="classification-card-body">
                    {/* هنا يمكن إضافة محتوى ديناميكي لعرض التصنيفات */}
                    {/* في الصورة، هذا القسم فارغ، لكن يمكن إضافة محتوى حسب الحاجة */}
                </Card.Body>
            </Card>
        </div>
    );
};

// تصدير المكون لاستخدامه في أماكن أخرى
export default ClassificationSection;
