// استيراد المكتبات اللازمة
import React, { useState, useEffect } from 'react'; // استيراد useState و useEffect لإدارة الحالة ودورة الحياة
import './TasksCard.css'; // استيراد ملف الأنماط الخاص ببطاقة المهام
import { Card, ListGroup, Form } from 'react-bootstrap'; // استيراد مكونات Card و ListGroup و Form

// تعريف مكون بطاقة المهام الوظيفي
const TasksCard = () => {
    // تعريف حالة لتخزين المهام
    const [tasks, setTasks] = useState([
        { id: 1, text: 'task 1', completed: false },
        { id: 2, text: 'task 2', completed: false },
        { id: 3, text: 'task 3', completed: false },
        { id: 4, text: 'task 4', completed: false },
        { id: 5, text: 'task 5', completed: false },
    ]);

    // تعريف حالة لتخزين نص المهمة الجديدة
    const [newTaskText, setNewTaskText] = useState('');

    // دالة لتغيير حالة اكتمال المهمة
    const toggleTaskCompletion = (taskId) => {
        setTasks(tasks.map(task => 
            task.id === taskId ? { ...task, completed: !task.completed } : task
        ));
    };

    // دالة لإضافة مهمة جديدة
    const addNewTask = () => {
        if (newTaskText.trim() !== '') {
            const newTask = {
                id: tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1,
                text: newTaskText,
                completed: false
            };
            setTasks([...tasks, newTask]);
            setNewTaskText(''); // إعادة تعيين حقل الإدخال
        }
    };

    // دالة لحذف مهمة
    const deleteTask = (taskId) => {
        setTasks(tasks.filter(task => task.id !== taskId));
    };

    // دالة لمعالجة الضغط على Enter في حقل الإدخال
    const handleKeyPress = (event) => {
        if (event.key === 'Enter') {
            event.preventDefault(); // منع السلوك الافتراضي للـ Enter في النموذج
            addNewTask();
        }
    };

    return (
        <Card className="tasks-card shadow-sm">
            {/* رأس البطاقة بعنوان "TASKS" */}
            <Card.Header className="tasks-card-header">
                TASKS
            </Card.Header>
            <Card.Body className="tasks-card-body">
                {/* قائمة المهام */}
                <ListGroup variant="flush" className="tasks-list">
                    {tasks.map(task => (
                        <ListGroup.Item key={task.id} className="d-flex align-items-center task-item">
                            {/* مربع اختيار لتحديد اكتمال المهمة */}
                            <Form.Check 
                                type="checkbox" 
                                className="me-2"
                                checked={task.completed}
                                onChange={() => toggleTaskCompletion(task.id)}
                                aria-label={`Mark task ${task.text} as completed`}
                            />
                            {/* نص المهمة مع تنسيق مختلف إذا كانت مكتملة */}
                            <span 
                                className={`flex-grow-1 ${task.completed ? 'text-decoration-line-through text-muted' : ''}`}
                            >
                                {task.text}
                            </span>
                            {/* زر حذف المهمة (يمكن إضافة أيقونة هنا) */}
                            <button 
                                className="btn btn-sm text-danger bg-transparent border-0"
                                onClick={() => deleteTask(task.id)}
                                aria-label={`Delete task ${task.text}`}
                            >
                                ×
                            </button>
                        </ListGroup.Item>
                    ))}
                </ListGroup>

                {/* حقل إدخال لإضافة مهمة جديدة */}
                <Form className="mt-3 d-flex">
                    <Form.Control
                        placeholder="Add new task..."
                        value={newTaskText}
                        onChange={(e) => setNewTaskText(e.target.value)}
                        onKeyPress={handleKeyPress}
                        className="new-task-input"
                    />
                    <button 
                        type="button" 
                        className="btn btn-sm btn-primary ms-2"
                        onClick={addNewTask}
                    >
                        Add
                    </button>
                </Form>
            </Card.Body>
        </Card>
    );
};

// تصدير المكون لاستخدامه في أماكن أخرى
export default TasksCard;
