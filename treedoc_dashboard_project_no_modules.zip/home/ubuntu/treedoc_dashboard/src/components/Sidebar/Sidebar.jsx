// استيراد المكتبات اللازمة
import React, { useState } from 'react'; // استيراد useState لإدارة الحالة
import './Sidebar.css'; // استيراد ملف الأنماط الخاص بالسايدبار
import { Nav } from 'react-bootstrap'; // استيراد مكون Nav من مكتبة react-bootstrap
import { 
    FaHome, FaFileAlt, FaProjectDiagram, FaWpforms, FaHistory, 
    FaSyncAlt, FaThLarge, FaChartBar, FaMapMarkedAlt, FaCog 
} from 'react-icons/fa'; // استيراد الأيقونات المطلوبة من مكتبة react-icons

// تعريف مكون السايدبار الوظيفي
const Sidebar = () => {
    // تعريف حالة لتخزين الرابط النشط حالياً
    const [activeLink, setActiveLink] = useState('#home');

    // دالة لمعالجة الضغط على رابط
    const handleNavClick = (eventKey) => {
        setActiveLink(eventKey);
        // يمكنك إضافة منطق التنقل الفعلي هنا (مثل استخدام React Router)
        console.log("Navigating to:", eventKey);
    };

    // تعريف بيانات الروابط لتجنب التكرار
    const navItems = [
        { eventKey: '#home', icon: FaHome, text: 'Home' },
        { eventKey: '#documents', icon: FaFileAlt, text: 'Documents' },
        { eventKey: '#workflows', icon: FaProjectDiagram, text: 'WorkFlows' },
        { eventKey: '#forms', icon: FaWpforms, text: 'Forms' },
        { eventKey: '#recent', icon: FaHistory, text: 'Recent' },
        { eventKey: '#brrow', icon: FaSyncAlt, text: 'Brrow' }, // الأيقونة والنص قد يحتاجان للمراجعة
        { eventKey: '#classification', icon: FaThLarge, text: 'classification' },
        { eventKey: '#reports', icon: FaChartBar, text: 'Reports' },
        { eventKey: '#archivemap', icon: FaMapMarkedAlt, text: 'Archive Map' },
    ];

    return (
        <div className="sidebar-container d-flex flex-column">
            {/* قسم اللوجو والعنوان */}
            <div className="sidebar-header text-center py-3">
                {/* يمكنك إضافة لوجو هنا إذا لزم الأمر */}
                <h3 className="text-white">Treedoc</h3>
            </div>
            
            {/* قسم روابط التنقل */}
            <Nav 
                className="flex-column flex-grow-1 px-3 sidebar-nav"
                activeKey={activeLink} // ربط الحالة بالـ activeKey
                onSelect={handleNavClick} // ربط دالة المعالجة بالـ onSelect
            >
                {navItems.map(item => (
                    <Nav.Link 
                        key={item.eventKey} 
                        href={item.eventKey} 
                        eventKey={item.eventKey} // مهم لـ onSelect
                        className="d-flex align-items-center my-1"
                    >
                        <item.icon className="me-2" /> {/* استخدام الأيقونة من البيانات */}
                        {item.text}
                    </Nav.Link>
                ))}
            </Nav>

            {/* قسم الإعدادات في الأسفل */}
            <Nav 
                className="flex-column px-3 sidebar-nav mt-auto mb-3"
                activeKey={activeLink}
                onSelect={handleNavClick}
            >
                <Nav.Link href="#settings" eventKey="#settings" className="d-flex align-items-center my-1">
                    <FaCog className="me-2" /> {/* أيقونة الإعدادات */}
                    Settings
                </Nav.Link>
            </Nav>

            {/* عنصر زخرفي برتقالي في الأسفل */}
            <div className="sidebar-footer-wave"></div>
        </div>
    );
};

// تصدير المكون لاستخدامه في أماكن أخرى
export default Sidebar;

