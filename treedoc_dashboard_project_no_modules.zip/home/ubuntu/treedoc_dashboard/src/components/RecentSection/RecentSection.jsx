// استيراد المكتبات اللازمة
import React from 'react';
import './RecentSection.css'; // استيراد ملف الأنماط الخاص بقسم الأحدث
import { Card } from 'react-bootstrap'; // استيراد مكون Card من react-bootstrap

// تعريف مكون قسم الأحدث الوظيفي
const RecentSection = () => {
    return (
        <div className="recent-section-container">
            {/* عنوان القسم */}
            <h5 className="section-title">Recent</h5>
            
            {/* بطاقة لعرض المحتوى الأخير */}
            <Card className="recent-card">
                <Card.Body className="recent-card-body">
                    {/* هنا يمكن إضافة محتوى ديناميكي للعناصر الأخيرة */}
                    {/* في الصورة، هذا القسم فارغ، لكن يمكن إضافة محتوى حسب الحاجة */}
                </Card.Body>
            </Card>
        </div>
    );
};

// تصدير المكون لاستخدامه في أماكن أخرى
export default RecentSection;
