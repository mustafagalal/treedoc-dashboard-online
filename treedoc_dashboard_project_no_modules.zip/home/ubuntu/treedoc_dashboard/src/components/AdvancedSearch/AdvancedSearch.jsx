// استيراد المكتبات اللازمة
import React, { useState } from 'react'; // استيراد useState لإدارة الحالة
import './AdvancedSearch.css'; // استيراد ملف الأنماط الخاص بالبحث المتقدم
import { Form, InputGroup, Button, Nav } from 'react-bootstrap'; // استيراد مكونات بوتستراب
import { FaSearch } from 'react-icons/fa'; // استيراد أيقونة البحث

// تعريف مكون البحث المتقدم الوظيفي
const AdvancedSearch = () => {
    // تعريف حالة لتخزين قيمة البحث
    const [searchTerm, setSearchTerm] = useState('');
    // تعريف حالة لتخزين التبويب النشط
    const [activeTab, setActiveTab] = useState('Keywords');

    // دالة لمعالجة التغيير في حقل الإدخال
    const handleInputChange = (event) => {
        setSearchTerm(event.target.value);
    };

    // دالة لمعالجة الضغط على زر البحث
    const handleSearchClick = () => {
        // هنا يمكنك إضافة منطق البحث الفعلي مع الفلاتر
        console.log('Advanced Search Term:', searchTerm, 'Active Filter:', activeTab);
        // يمكنك استدعاء دالة بحث تمرر لها searchTerm و activeTab
    };

    // دالة لمعالجة الضغط على Enter في حقل الإدخال
    const handleKeyPress = (event) => {
        if (event.key === 'Enter') {
            event.preventDefault(); // منع السلوك الافتراضي للـ Enter في النموذج
            handleSearchClick();
        }
    };

    // دالة لمعالجة اختيار تبويب الفلتر
    const handleTabSelect = (selectedKey) => {
        setActiveTab(selectedKey);
        // يمكنك إضافة منطق هنا لتغيير حقول الفلترة المعروضة بناءً على التبويب
        console.log('Selected Filter Tab:', selectedKey);
    };

    return (
        <div className="advanced-search-container">
            {/* عنوان قسم البحث المتقدم */}
            <h5 className="search-title">Advanced search</h5>
            
            {/* نموذج البحث المتقدم */}
            <Form onSubmit={(e) => e.preventDefault()}> {/* منع إرسال النموذج الافتراضي */}
                {/* حقل البحث الرئيسي */}
                <InputGroup className="mb-3">
                    <Form.Control
                        placeholder="Search"
                        aria-label="Advanced Search"
                        className="search-input"
                        value={searchTerm}
                        onChange={handleInputChange}
                        onKeyPress={handleKeyPress}
                    />
                    <Button 
                        variant="outline-secondary" 
                        className="search-button"
                        onClick={handleSearchClick}
                    >
                        <FaSearch />
                    </Button>
                </InputGroup>
                
                {/* شريط التبويب للفلاتر */}
                <Nav 
                    className="filter-tabs mb-3" 
                    variant="tabs" 
                    activeKey={activeTab} // ربط التبويب النشط بالحالة
                    onSelect={handleTabSelect} // ربط دالة معالجة اختيار التبويب
                >
                    <Nav.Item>
                        <Nav.Link eventKey="Keywords" className="filter-tab">Keywords</Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                        <Nav.Link eventKey="Date" className="filter-tab">Date</Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                        <Nav.Link eventKey="Location" className="filter-tab">Location</Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                        <Nav.Link eventKey="Type" className="filter-tab">Type</Nav.Link>
                    </Nav.Item>
                </Nav>
                
                {/* هنا يمكن عرض حقول فلترة إضافية بناءً على activeTab */}
                {/* مثال بسيط: */}
                {/* {activeTab === 'Date' && ( <Form.Control type="date" placeholder="Select date" /> )} */}

            </Form>
        </div>
    );
};

// تصدير المكون لاستخدامه في أماكن أخرى
export default AdvancedSearch;
